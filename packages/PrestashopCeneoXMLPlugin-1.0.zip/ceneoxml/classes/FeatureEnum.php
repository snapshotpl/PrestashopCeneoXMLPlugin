<?php

abstract class FeatureEnum
{
    const Weight = 4;
}