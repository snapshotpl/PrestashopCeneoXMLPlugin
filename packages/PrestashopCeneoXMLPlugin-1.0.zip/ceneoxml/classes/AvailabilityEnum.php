<?php

abstract class AvailabilityEnum
{
    const Unavailable = 0;
    const Available = 1;
    const LackOfInformation = 99;    
}