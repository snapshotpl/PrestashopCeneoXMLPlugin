<?php

class CeneoConfig
{
    const XmlUrlLength = 2048;
    const XmlCategoryPathLength = 255;
    const XmlImageLength = 255;
    const XmlProductNameLength = 150;	
    const XmlProductDesc = 30000;
    
    const Encoding = 'UTF-8';
}